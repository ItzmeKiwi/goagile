<?php

namespace App\Http\Requests;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class OnboardRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        //return false;
        return Auth::check();
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'otp'  => 'required|string|min:3|max:10',
            'vat_number'  => 'required|string|min:3|max:50',
            'device_id'  => 'required|string|min:3|max:50',
			'invoice_type' => 'required',
            'org_name'  => 'required|string|min:3|max:191',
            'org_unit'  => 'required|string|min:3|max:191',
            'business_category'  => 'required|string|min:2|max:191',
            'country_code'  => 'required|string|min:2|max:10',
            'email_id'  => 'required|string|min:5|max:50',
            'registered_address'  => 'required|string|min:10|max:500'
        ];
    }
}
