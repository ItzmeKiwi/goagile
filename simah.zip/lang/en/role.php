<?php

return [
	"general" => [
		"title"               => "Role",
		"subtitle"            => "Roles",
		"panel_title"         => "List of all Roles",
		"sidebar_title"       => "Role",
		"delete_confirmation" => "Are you sure you want to delete?",
		"delete_title"        => "Confirm Deletion",


	],
	"buttons" => [
		"text"  => [
			"all"    => "Show All Roles",
			"add"    => "Add",
			"edit"   => "Edit",
			"delete" => "Delete",
			"cancel" => "Cancel",

		],
		"title" => [
			"all"    => "Show All Roles",
			"add"    => "Add Role",
			"edit"   => "Edit Role",
			"delete" => "Delete Role",
			"cancel" => "Cancel",
		]

	],
	"fields"  => [
		"labels"      => [
			"country_id"   => "Country",
			"language_id"  => "Language",
			"category_id"  => "Site Category",
			"name"         => "Name",
			"display_name" => "Display Name",
			"description"  => "Description",
			"status"       => "Status",
			"permission"   => "List of Permissions"
		],
		"placeholder" => [
			"country_id"   => "Choose Country",
			"language_id"  => "Choose Language",
			"category_id"  => "Choose Site Category",
			"name"         => "Enter Name",
			"display_name" => "Enter Display Name",
			"description"  => "Enter Description",
			"status"       => "Choose Status",
		],
		"headers"     => [
			"language"     => "Language",
			"category"     => "Site Category",
			"name"         => "Name",
			"display_name" => "Display Name",
			"description"  => "Description",
			"status"       => "Status",
			"action"       => "Action"
		]
	],
	"message" => [
		"add_success"    => "Role successfully added",
		"edit_success"   => "Role successfully updated",
		"delete_success" => "Role successfully deleted",
		"add_error"      => "Unable to add Role. Please try again later.",
		"edit_error"     => "Unable to update Role. Please try again later.",
		"delete_error"   => "Unable to delete Role. Please try again later.",
		"failure"        => "Woops! Something went wrong. Please try again later. Contact your Administrator",
		"invalid"        => "Invalid Role",
		"invalid_access" => "You don't have sufficient permission to view information",
		"login_active"   => "You account is not active. Contact Administrator.",
	],

];