<?php
 

return [
	"general" => [
		"title"               => "User",
		"subtitle"            => "Users",
		"panel_title"         => "List of all Users",
		"sidebar_title"       => "User",
		"delete_confirmation" => "Are you sure you want to delete?",
		"delete_title"        => "Confirm Deletion",


	],
	"buttons" => [
		"text"  => [
			"all"    => "Show All Users",
			"add"    => "Add",
			"edit"   => "Edit",
			"delete" => "Delete",
			"cancel" => "Cancel",

		],
		"title" => [
			"all"    => "Show All Users",
			"add"    => "Add User",
			"edit"   => "Edit User",
			"delete" => "Delete User",
			"cancel" => "Cancel",
		]

	],
	"fields"  => [
		"labels"      => [
			"country_id"            => "Country",
			"language_id"           => "Language",
			"category_id"           => "Site Category",
			"itemcategory_id"       => "User Category",
			"full_name"             => "Full Name",
			"name"                  => "Name",
			"username"              => "Username",
			"email"                 => "Email",
			"phone"                 => "Phone",
			"password"              => "Password",
			"password_confirmation" => "Confirm Password",
			"image"                 => "Image",
			"status"                => "Status",
			"role_id"               => "Role"
		],
		"placeholder" => [
			"country_id"            => "Choose Country",
			"language_id"           => "Choose Language",
			"category_id"           => "Choose Site Category",
			"itemcategory_id"       => "Choose User Category",
			"full_name"             => "Enter Full Name",
			"name"                  => "Enter Name",
			"username"              => "Enter Username",
			"email"                 => "Enter Email",
			"phone"                 => "Enter Phone",
			"password"              => "Enter Password",
			"password_confirmation" => "Re-Enter Password",
			"image"                 => "Choose Image",
			"status"                => "Choose Status",
			"role_id"               => "Choose User Role"
		],
		"headers"     => [
			"language"  => "Language",
			"category"  => "Site Category",
			"country"   => "Country",
			"full_name" => "Full Name",
			"name"      => "Name",
			"role"      => "Role",
			"username"  => "Username",
			"email"     => "Email",
			"phone"     => "Phone",
			"image"     => "Image",
			"status"    => "Status",
			"action"    => "Action"
		]
	],
	"message" => [
		"add_success"    => "User successfully added",
		"edit_success"   => "User successfully updated",
		"delete_success" => "User successfully deleted",
		"add_error"      => "Unable to add User. Please try again later.",
		"edit_error"     => "Unable to update User. Please try again later.",
		"delete_error"   => "Unable to delete User. Please try again later.",
		"failure"        => "Woops! Something went wrong. Please try again later. Contact your Administrator",
		"invalid"        => "Invalid User",
		"invalid_access" => "You don't have sufficient permission to view information",
		"login_active"   => "You account is not active. Contact Administrator.",
	],


	"profile" => [
		"edit_profile" => "Edit Profile",
		"follow_me"    => "Follow Me",
		"form_heading" => [
			"personal_information" => "Personal Information",
			"address_information"  => "Address Information",
			"relation_information" => "Relation Information",
			"social_information"   => "Social Media Information",
		]
	],

];
