<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Schema::defaultStringLength(191);

		/*Einvoicing API Auth*/

		$authpostjson='{
			"vat_number": "'.config('einvoice.API_AUTH_VAT_NUMBER').'",
			"username": "'.config('einvoice.API_AUTH_USERNAME').'",
			"secret": "'.config('einvoice.API_AUTH_SECRET').'"
		}';
		$AUTH_CURL = curl_init();

		curl_setopt_array($AUTH_CURL, array(
		  CURLOPT_URL => config('einvoice.API_HOST').":".config('einvoice.API_PORT').config('einvoice.API_AUTH_URL'),
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>$authpostjson,
		  CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json'
		  ),
		));
		$API_AUTH_RESPONSE = curl_exec($AUTH_CURL);
		curl_close($AUTH_CURL);
		$API_AUTH_RESPONSE=json_decode($API_AUTH_RESPONSE,true);
		session()->put('API_AUTH_TOKEN', $API_AUTH_RESPONSE["token"]);

    }
}
