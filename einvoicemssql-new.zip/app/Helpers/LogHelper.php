<?php

namespace App\Helpers;

use Illuminate\Support\Facades\Log;

class LogHelper {
	public static function logError( $ex, $string = '' ) {
		Log::critical( $string . ":\n" . $ex->getMessage() . " in " . $ex->getFile() . " at Line " . $ex->getLine() . ". \n[stacktrace]\n" . $ex->getTraceAsString() );
	}

	public static function logInfo( $string, $data ) {
		Log::info( $string . json_encode( $data ) );
	}
}