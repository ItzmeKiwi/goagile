<?php

namespace App\Http\Controllers;

use App\Helpers\LogHelper;
use Illuminate\Http\Request;
use App\Http\Requests\OnboardRequest;

ini_set('max_execution_time', 900); //3 minutes

class OnboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

	public function index()
    {
		
		$ONBOARD_CURL = curl_init();

		curl_setopt_array($ONBOARD_CURL, array(
		  CURLOPT_URL => config('einvoice.API_HOST').":".config('einvoice.API_PORT').config('einvoice.API_LIST_ONBOARDINGS'),
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json',
			'Authorization: '.session()->get('API_AUTH_TOKEN')
		  )
		));
		$ONBOARD_RESPONSE = curl_exec($ONBOARD_CURL);
		curl_close($ONBOARD_CURL);
		$ONBOARD_RESPONSE=json_decode($ONBOARD_RESPONSE,true);

        return view('panel/onboard/index')
			->with('ONBOARD_RESPONSE',$ONBOARD_RESPONSE);
    }

	public function create() {
		return view('panel/onboard/form');
	}

	public function store(OnboardRequest $request)
	{
        $data = $request->all();

		try {

		$ONBOARD_STORE_CURL = curl_init();

		curl_setopt_array($ONBOARD_STORE_CURL, array(
		  CURLOPT_URL => config('einvoice.API_HOST').":".config('einvoice.API_PORT').config('einvoice.API_STORE_ONBOARDINGS'),
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>'{
			"otp": "'.trim($data['otp']).'",
			"vat_number":"'.trim($data['vat_number']).'",
			"device_id": "'.trim($data['device_id']).'",
			"invoice_type":"'.trim($data['invoice_type']).'",
			"org_name":"'.trim($data['org_name']).'",
			"org_unit":"'.trim($data['org_unit']).'",
			"business_category":"'.trim($data['business_category']).'",
			"registered_address":"'.trim($data['registered_address']).'",
			"country_code":"'.trim($data['country_code']).'",
			"email_id":"'.trim($data['email_id']).'"
		  }',
		  CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json',
			'Authorization: '.session()->get('API_AUTH_TOKEN')
		  )
		));
		$ONBOARD_STORE_RESPONSE = curl_exec($ONBOARD_STORE_CURL);
		curl_close($ONBOARD_STORE_CURL);
		$ONBOARD_STORE_RESPONSE=json_decode($ONBOARD_STORE_RESPONSE,true);

			if ( $ONBOARD_STORE_RESPONSE["status"]=="Success" ) {
				return redirect( 'panel/onboard' )
					->with( 'message', $ONBOARD_STORE_RESPONSE["message"] );
			} else {
				return redirect()
					->back()
					->with( 'error', $ONBOARD_STORE_RESPONSE["message"] );
			}

		} catch ( \Exception $ex ) {
			LogHelper::logError( $ex, 'Onboard Submit Page' );
			return redirect( 'panel/onboard/add' )
				->with( 'error', Lang::get( 'general.message.failure', [ 'attribute' => 'Onboard' ] ) );
		}
    }

	public function invoices( $onboard_id , $vat_number , $page_number )
	{

		$limit='&page=1';
		if(isset($page_number)){
			$page=$page_number;
			if($page>0){
				$limit='&page='.$page.'';		
			}
		}

		$count=1;

		if($page>1){
			$count=($page-1)*10;
			$count=$count+1;
		}

		$ONBOARD_INVOICES_CURL = curl_init();
		curl_setopt_array($ONBOARD_INVOICES_CURL, array(
		  CURLOPT_URL => config('einvoice.API_HOST').":".config('einvoice.API_PORT').config('einvoice.API_LIST_INVOICES').$onboard_id.'/invoices?noxml=noxml&page_size=10'.$limit,
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json',
			'Authorization: '.session()->get('API_AUTH_TOKEN')
		  )
		));
		$ONBOARD_INVOICES_RESPONSE = curl_exec($ONBOARD_INVOICES_CURL);
		curl_close($ONBOARD_INVOICES_CURL);
		$ONBOARD_INVOICES_RESPONSE=json_decode($ONBOARD_INVOICES_RESPONSE,true);

		$TOTAL_RECORDS=800;
		return view('panel/invoice/index')
			->with('ONBOARD_INVOICES_RESPONSE',$ONBOARD_INVOICES_RESPONSE)
			->with('count',$count)
			->with('page',$page)
			->with('TOTAL_RECORDS',$TOTAL_RECORDS)
			->with('onboard_id',$onboard_id)
			->with('vat_number',$vat_number);
	}

	public function creditnotes( $onboard_id , $vat_number )
	{
		$ONBOARD_CREDITNOTES_CURL = curl_init();
		curl_setopt_array($ONBOARD_CREDITNOTES_CURL, array(
		  CURLOPT_URL => config('einvoice.API_HOST').":".config('einvoice.API_PORT').config('einvoice.API_LIST_INVOICES').$onboard_id.'/credit-notes',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'GET',
		  CURLOPT_HTTPHEADER => array(
			'Content-Type: application/json',
			'Authorization: '.session()->get('API_AUTH_TOKEN')
		  )
		));
		$ONBOARD_CREDITNOTES_RESPONSE = curl_exec($ONBOARD_CREDITNOTES_CURL);
		curl_close($ONBOARD_CREDITNOTES_CURL);
		$ONBOARD_CREDITNOTES_RESPONSE=json_decode($ONBOARD_CREDITNOTES_RESPONSE,true);

		return view('panel/creditnotes/index')
			->with('ONBOARD_CREDITNOTES_RESPONSE',$ONBOARD_CREDITNOTES_RESPONSE)
			->with('onboard_id',$onboard_id)
			->with('vat_number',$vat_number);
	}

	public function downloadXml( $invoice_uuid , $onboard_id )
	{
		return view('panel/invoice/xml')
			->with('API_AUTH_TOKEN',session()->get('API_AUTH_TOKEN'))
			->with('onboard_id',$onboard_id)
			->with('invoice_uuid',$invoice_uuid);
	}

}
