<?php

 

return [
	"general" => [
		"personal_information"	=> "User Information",
		"social_media_information"	=> "Social Media Information",
		"sub_title"	=> "About User",
		"phone_number"	=> "Phone Number",
		"religion"	=> "Religion",
		"gotra"	=> "Gotra",
		"diet_preference" => "Diet Preference",
		"address"	=> "Address"
	],
	"fields"  => [
		"labels"      => [
			"first_name"       => "First Name",
			"middle_name"      => "Middle Name",
			"last_name"      => "Last Name",
			"email"  => "Email",
			"phone"	=> "Phone",
			"about_me"      => "About Me",
			"facebook_link" => "Facebook Link",
			"twitter_link"	=> "Twitter Link",
			"linkedin_link"	=> "LinkedIn Link",
			"instagram_link" 	=> "Instagram Link",
			"youtube_link" 	=> "Youtube Link",
			"website_link"	=> "Website/Blog Link"
		],
		"placeholder" => [
			"first_name"       => "Ente First Name",
			"middle_name"      => "Ente Middle Name",
			"last_name"      => "Ente Last Name",
			"email"  => "Ente Email",
			"phone"	=> "Ente Phone No.",
			"about_me"      => "About Me",
			"facebook_link" => "Ente Facebook Link",
			"twitter_link"	=> "Ente Twitter Link",
			"linkedin_link"	=> "Ente LinkedIn Link",
			"instagram_link" 	=> "Ente Instagram Link",
			"youtube_link" 	=> "Ente Youtube Link",
			"website_link"	=> "Ente Website/Blog Link"
		]
	],
	"message" => [
		"edit_success"    => "Information successfully updated"
	]
];
