<?php
return [
	"application"    => env('APP_NAME'),
	"dashboard"      => "Dashboard",
	"access_title"   => "Access Denied",
	"edit_button"    => "Edit",
	"delete_button"  => "Delete",
	"cancel_button"  => "Cancel",
	"update_button"  => "Update",
	"save_button"    => "Save",
	"back_button"    => "Back",
	"done_button"    => "Done",
	"export_button"  => "Export Data",
	"upload_button"  => "Upload",
	"created_at"     => "Creation Date",
	"updated_at"     => "Updation Date",
	"create_by"      => "Created By",
	"updated_by"     => "Updated By",
	"reviewed_by"    => "Reviewed By",
	"approved_by"    => "Approved By",
	"action"         => "Actions",
	"edit"           => "Edit",
	"delete"         => "Delete",
	"delete_title"   => "Delete Confirmation?",
	"delete_confirm" => "Are you sure you want to delete?",
	"submitted_by"   => "Submitted By",
	"liked"          => "Liked",
	"disliked"       => "Disliked",
	"views"          => "Views",
	"like"           => "Like",
	"dislike"        => "Dislike",
	"author"         => "Author",
	"category"       => "Category",
	"date"           => "Date",
	"sort_by"        => "Sort By",
	"language"       => "Language",
	"photo_credit"   => "Photo Credit",
	"copyright"      => "Copyright",
	"uploaded_image" => "Image Uploaded",

	"message" => [
		"login_failure"  => "Incorrect Username/Password",
		"logout_success" => "You are successfully Logged Out!",
		"access_denied"  => "Restricted Area. Permission Denied",
		"login_active"   => "You account is not active. Contact Administrator.",
		"failure"        => "Woops! Something went wrong. Please try again.",
	],

	"delete" => [
		"delete_title"        => "Delete",
		"delete_confirmation" => "Are you sure you want to delete?",
		"delete"              => "Delete",
		"cancel"              => "Cancel",
	],

	"label" => [
		"signout"  => "Sign out",
		"signin"   => "Sign In",
		"forgot"   => "Forgot Your Password?",
		"register" => "Register Now!",
		"remember" => "Remember Me"
	],

	"button" => [
		"support"         => "Support",
		"patron"         => "Patron",
		"signin"         => "Sign In",
		"register"       => "Register",
		"password_reset" => "Send Password Reset Link"
	],

	"login" => [
		"title"           => "LOGIN HERE",
		"text"            => "Log in using the email address and password you registered with in order to access your dashboard.",
		"username"        => "Email/Username",
		"password"        => "Password",
		"forgot_password" => "Forgot Password?",
		"submit_button"   => "Login",
		"register_text"   => "Dont have an account? Please",
		"click_here"      => "Click Here"
	],

	"register" => [
		"title"                 => "REGISTER NOW",
		"fullname"              => "Full Name",
		"username"              => "Username",
		"mobile"                => "Mobile Number",
		"email"                 => "Email",
		"password"              => "Password",
		"password_confirmation" => "Confirm Password",
		"agree_terms"           => "I agree to Terms and Conditions",
		"register"              => "Register",
		"existing"              => "Already have an Account?",
		"please"                => "Please",
		"click_here"            => "Click Here",
		"mobile_info"           => "Please Provide a valid Phone Number in order to verify your account. We will send you a verification code.",
		"register_info"         => "Please fill in details to create a account with us!"
	],

	"filter" => [
		"featured"       => "Choose Featured",
		"status"         => "Choose Status",
		"publish_status" => "Choose Publish Status",
		"country"        => "Choose Country",
		"language"       => "Choose Language",
		"category"       => "Choose Category"
	]
];
